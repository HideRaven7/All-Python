# automate-the-boring-stuff-with-python
 My code and note for this book
